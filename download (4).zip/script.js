let nomePadaria = "Padaria Doce Sabor";
const enderecoPadaria = "Rua do Sol, 3000";
var telefonePadaria = "(99) 9999-9999"; // Embora 'var' seja menos comum hoje em dia, vamos usá-lo para testar.
let precoPaoFrances = 0.50;
const precoBoloChocolate = 25.00;
let precoCafe = 3.50;
let estoquePaoFrances = 100;
let estoqueBoloChocolate = 10;
let estoqueCafe = 50;
const produtosDisponiveis = ["Pão Francês", "Bolo de Chocolate", "Café", "Croissant", "Sonho"];
let categoriasProdutos = ["Pães", "Bolos", "Bebidas", "Doces"];
const paoFrances = {
    nome: "Pão Francês",
    preco: 0.50,
    estoque: 100,
    categoria: "Pães"
};

const boloChocolate = {
    nome: "Bolo de Chocolate",
    preco: 25.00,
    estoque: 10,
    categoria: "Bolos"
};
nomePadaria = "Doce Sabor Padaria e Confeitaria"; // Funciona com let
// enderecoPadaria = "Nova Rua"; // Isso daria erro, pois const não permite reatribuição
telefonePadaria = "(88) 8888-8888"; // Funciona com var
console.log("Nome da Padaria:", nomePadaria);
console.log("Endereço:", enderecoPadaria);
console.log("Telefone:", telefonePadaria);
console.log("Preço do Pão Francês:", precoPaoFrances);
console.log("Estoque de Bolo de Chocolate:", estoqueBoloChocolate);
console.log("Produtos Disponíveis:", produtosDisponiveis);
console.log("Categorias:", categoriasProdutos);
console.log("Detalhes do Pão Francês:", paoFrances);


// ... (código anterior da Atividade 2) ...

// Obter referências aos elementos HTML para conversão de moeda
const spanTotalUSD = document.getElementById('totalUSD');
const spanTotalEUR = document.getElementById('totalEUR');

// ... (resto do código da Atividade 2) ...

function atualizarCalculadora(valorPagoAtual = 0) { // Definir valor padrão 0
    // ... (código anterior para calcular subtotal, desconto, impostos, troco, etc.) ...
    let valorPago = parseFloat(valorPagoAtual); // Garante que é um número decimal
    // Implementar conversor de moeda (Real -> USD/EUR)
    const taxaCambioUSD = 5.0; // Exemplo: 1 Real = 5.0 USD (em um sistema real, obter isso de uma API)
    const taxaCambioEUR = 6.0; // Exemplo: 1 Real = 6.0 EUR (em um sistema real, obter isso de uma API)

    let totalUSD = totalGeral / taxaCambioUSD;
    let totalEUR = totalGeral / taxaCambioEUR;

    // ... (código anterior para atualizar spanSubtotal, spanTotal, spanTroco) ...

    // Atualizar os elementos HTML com os resultados da conversão formatados
    spanTotalUSD.textContent = totalUSD.toFixed(2); // Formata para 2 casas decimais
    spanTotalEUR.textContent = totalEUR.toFixed(2);

    // ... (resto do código da função) ...
}

// ... (ouvintes de evento e chamada inicial) ...
// Atividade 2: Operações Matemáticas e Calculadora
document.addEventListener('DOMContentLoaded', () => {
    renderizarClientes(); // Chamar ao carregar a página para exibir a lista inicial

// Obter referências aos elementos HTML
const InputQuantidade = document.getElementById('quantidade');
const SpanSubtotal = document.getElementById('subtotal');
const SpanTotal = document.getElementById('total');
const InputValorPago = document.getElementById('valorPago');
const SpanTroco = document.getElementById('troco'); // Já estava aqui
const SpanTotalUSD = document.getElementById('totalUSD');
const SpanTotalEUR = document.getElementById('totalEUR');
const spanPontosFidelidade = document.getElementById('pontosFidelidade'); // Novo

    // Funcionalidade do Carrossel na seção "Nossos Produtos" (mantida dentro DOMContentLoaded)
    const carouselSlides = document.querySelector('.carousel-slides');
    const slides = document.querySelectorAll('.carousel-slide');
    const btnPrev = document.querySelector('.carousel-prev');
    const btnNext = document.querySelector('.carousel-next');

// Vamos adicionar um preço de exemplo para um produto por enquanto
const precoProdutoExemplo = 10.00; // Preço unitário do produto

// Função para atualizar os cálculos e a interface
function atualizarCalculadora() {
    // Obter os valores atuais dos inputs
    let quantidade = parseInt(inputQuantidade.value); // Garante que é um número inteiro

    // Validar a quantidade
    if (isNaN(quantidade) || quantidade < 0) {
        quantidade = 0;
        inputQuantidade.value = 0; // Resetar o input se for inválido
    }

    // Validar o valor pago (a validação já pode ter acontecido no listener de input do valorPago)
     if (isNaN(valorPago) || valorPago < 0) {
        valorPago = 0;
        // inputValorPago.value = 0; // Não resetamos o input aqui, apenas usamos o valor validado
    }


    // Calcular subtotal a partir dos itens no carrinho
    let subtotal = 0; // Inicializa subtotal
    carrinho.forEach(item => { // Itera sobre os itens no carrinho
        subtotal += item.produto.preco * item.quantidade; // Soma o subtotal de cada item

    });

    // Aplicar descontos (exemplo: 10% de desconto para quantidade > 5)
    let desconto = 0;
    if (quantidade > 5) {
        desconto = subtotal * 0.10;
    }
    let subtotalComDesconto = subtotal - desconto;

    // Calcular impostos (exemplo: 5%) e taxa de entrega (exemplo: R$ 10)
    const imposto = subtotalComDesconto * 0.05;
    const taxaEntrega = 10.00;
    let totalGeral = subtotalComDesconto + imposto + taxaEntrega;

    // Calcular troco
    let troco = valorPago - totalGeral;

    // Implementar pontos de fidelidade (1 ponto = R$ 1 do total geral)
    let pontosFidelidadeGanhos = Math.floor(totalGeral); // Pontos inteiros

    // Implementar conversor de moeda (Real -> USD/EUR)
    const taxaCambioUSD = 5.0; // Exemplo: 1 Real = 5.0 USD (em um sistema real, obter isso de uma API)
    const taxaCambioEUR = 6.0; // Exemplo: 1 Real = 6.0 EUR (em um sistema real, obter isso de uma API)

    let totalUSD = totalGeral / taxaCambioUSD;
    let totalEUR = totalGeral / taxaCambioEUR;


    // Atualizar os elementos HTML com os resultados formatados
    spanSubtotal.textContent = subtotal.toFixed(2); // Formata para 2 casas decimais
    spanTotal.textContent = totalGeral.toFixed(2);
    spanTroco.textContent = troco.toFixed(2);
    spanTotalUSD.textContent = totalUSD.toFixed(2);
    spanTotalEUR.textContent = totalEUR.toFixed(2);
    spanPontosFidelidade.textContent = pontosFidelidadeGanhos; // Novo

}

    // Adicionar ouvintes de evento para atualizar a calculadora (dentro DOMContentLoaded)
    if (InputQuantidade) {
        InputQuantidade.addEventListener('input', () => {
            atualizarCalculadora(InputValorPago.value); // Passa o valorPago atual
        });
    }
    if (InputValorPago) {
        InputValorPago.addEventListener('input', () => {
            atualizarCalculadora(InputValorPago.value); // Passa o valorPago atual
        });
    }
    // Opcional: Chamar a função uma vez ao carregar a página para mostrar os valores iniciais (dentro DOMContentLoaded)
    // Verificar se os elementos existem antes de chamar
    if (InputQuantidade && InputValorPago && SpanSubtotal && SpanTotal && SpanTroco && SpanTotalUSD && SpanTotalEUR && spanPontosFidelidade) {
        // atualizarCalculadora(); // Esta chamada inicial agora pode não ser necessária se o carrinho começa vazio e é renderizado.
    }


    // Funcionalidade do Carrossel na seção "Nossos Produtos" (modificada para rolagem)

    let currentIndex = 0;
    const totalSlides = slides.length;
    const slideWidth = slides.length > 0 ? slides[0].offsetWidth : 0; // Obter largura de um slide

    // Função para rolar para um slide específico
    function scrollToSlide(index) {
        if (carouselSlides && slideWidth > 0) {
            carouselSlides.scrollLeft = index * slideWidth;
        }
    }

    // Adiciona ouvintes de evento aos botões de navegação (se existirem)
    if (btnNext) {
        btnNext.addEventListener('click', () => {
            currentIndex = (currentIndex + 1) % totalSlides;
            scrollToSlide(currentIndex);
        });
    }
    if (btnPrev) {
        btnPrev.addEventListener('click', () => {
            currentIndex = (currentIndex - 1 + totalSlides) % totalSlides;
            scrollToSlide(currentIndex);
        });
    }

}); // Fim do DOMContentLoaded para a calculadora e carrossel

// Atividade 3: Integrar validação de formulário (dentro DOMContentLoaded)
// Integrado no primeiro DOMContentLoaded para evitar múltiplos ouvintes

    const formularioPedidoEspecial = document.querySelector('form[action="/processar_pedido_especial"]');

    if (formularioPedidoEspecial) {
        formularioPedidoEspecial.addEventListener('submit', function(event) { // Usando function para manter 'this' se necessário no futuro
            const nomePedidoInput = document.getElementById('nome_pedido');
            const telefonePedidoInput = document.getElementById('telefone_pedido');
            const emailPedidoInput = document.getElementById('email_pedido');

            const erroNomeSpan = document.getElementById('erro-nome-pedido');
            const erroTelefoneSpan = document.getElementById('erro-telefone-pedido');
            const erroEmailSpan = document.getElementById('erro-email-pedido');

            let formularioValido = true;

            if (!validarEntradaNaoVazia(nomePedidoInput.value)) {
                erroNomeSpan.textContent = 'Por favor, preencha o campo Nome Completo.';
                formularioValido = false;
            } else {
                erroNomeSpan.textContent = ''; // Limpa a mensagem de erro se válido
            }

            // Validação para telefone: não vazio e apenas números
            if (!validarEntradaNaoVazia(telefonePedidoInput.value)) {
                 erroTelefoneSpan.textContent = 'Por favor, preencha o campo Telefone.';
                 formularioValido = false;
            } else if (!validarApenasNumeros(telefonePedidoInput.value)) {
                 erroTelefoneSpan.textContent = 'Por favor, insira apenas números no campo Telefone.';
                 formularioValido = false;
            } else {
                 erroTelefoneSpan.textContent = ''; // Limpa a mensagem de erro se válido
            }

// Atividade 4: Integrar formulário de cadastro com lista de clientes frequentes
document.addEventListener('DOMContentLoaded', () => {
 popularSelectClientes(); // Adiciona a chamada aqui

 const formularioCadastro = document.querySelector('form[action="/processar_cadastro_newsletter"]');
 if (formularioCadastro) {
        formularioCadastro.addEventListener('submit', (event) => {
            event.preventDefault(); // Impede a submissão padrão do formulário
            let formularioValido = true;

            // Obter referências aos elementos de input e erro
            const nomeCompletoInput = document.getElementById('nome_completo_cadastro');
            const emailCadastroInput = document.getElementById('email_cadastro');

            const erroNomeCadastroSpan = document.getElementById('erro-nome-completo-cadastro');
            const erroEmailCadastroSpan = document.getElementById('erro-email-cadastro');

            // Validação do Nome Completo
            if (!validarEntradaNaoVazia(nomeCompletoInput.value)) {
                erroNomeCadastroSpan.textContent = 'Por favor, preencha o campo Nome Completo.';
                formularioValido = false;
            } else {
                erroNomeCadastroSpan.textContent = '';
            }

            // Validação do Email
            if (!validarEntradaNaoVazia(emailCadastroInput.value)) {
                erroEmailCadastroSpan.textContent = 'Por favor, preencha o campo Email.';
                formularioValido = false;
            } else {
                erroEmailCadastroSpan.textContent = '';
            }

            // Obter referências para os campos de telefone, número e CEP, e seus spans de erro
            const telefoneCadastroInput = document.getElementById('telefone_cadastro');
            const numeroCadastroInput = document.getElementById('numero_cadastro');
            const cepCadastroInput = document.getElementById('cep_cadastro');

            const erroTelefoneCadastroSpan = document.getElementById('erro-telefone-cadastro');
            const erroNumeroCadastroSpan = document.getElementById('erro-numero-cadastro');
            const erroCepCadastroSpan = document.getElementById('erro-cep-cadastro');

            // Validação do Telefone (não vazio e apenas números)
            if (!validarEntradaNaoVazia(telefoneCadastroInput.value)) {
                erroTelefoneCadastroSpan.textContent = 'Por favor, preencha o campo Telefone.';
                formularioValido = false;
            } else if (!validarApenasNumeros(telefoneCadastroInput.value)) {
                erroTelefoneCadastroSpan.textContent = 'Por favor, insira apenas números no campo Telefone.';
                formularioValido = false;
            } else {
                erroTelefoneCadastroSpan.textContent = '';
            }

            // Validação do Número (não vazio e apenas números)
            if (!validarEntradaNaoVazia(numeroCadastroInput.value)) {
                erroNumeroCadastroSpan.textContent = 'Por favor, preencha o campo Número.';
                formularioValido = false;
            } else if (!validarApenasNumeros(numeroCadastroInput.value)) {
                erroNumeroCadastroSpan.textContent = 'Por favor, insira apenas números no campo Número.';
                formularioValido = false;
            } else {
                erroNumeroCadastroSpan.textContent = '';
            }

            // Validação do CEP (formato ddddd-ddd)
            const cepRegex = /^\d{5}-\d{3}$/; // Corrigindo regex no prompt anterior, estava com erro
            if (!validarEntradaNaoVazia(cepCadastroInput.value) || !cepRegex.test(cepCadastroInput.value)) {
                erroCepCadastroSpan.textContent = 'Por favor, insira um CEP válido no formato 12345-678.';
                formularioValido = false;
            } else {
                erroCepCadastroSpan.textContent = '';
            }

            // Validação da caixa de seleção de Termos
            const aceitaTermosCheckbox = document.getElementById('aceita_termos');
            const erroTermosSpan = document.getElementById('erro-termos-aceitos');
            if (!aceitaTermosCheckbox.checked) {
                erroTermosSpan.textContent = 'Você deve aceitar os termos e condições.';
                formularioValido = false;
            } else {
                erroTermosSpan.textContent = '';
            }

            if (!formularioValido) {
                // event.preventDefault(); // Já está no topo do listener, manter ou remover dependendo se quer submeter válido
            }
 else {
 // Formulário de cadastro é válido, criar e adicionar cliente
 const nome = nomeCompletoInput.value;
 const email = emailCadastroInput.value;
 const telefone = telefoneCadastroInput.value;

 // Criar um novo objeto cliente
 // ID simples baseado no tamanho atual do array + 1
 const novoCliente = {
 id: clientesFrequentes.length + 1,
 nome: nome,
 telefone: telefone, // Assumindo que o campo de telefone é para o cliente
 email: email,
 pontos: 0 // Novo cliente começa com 0 pontos
 // Você pode adicionar mais propriedades aqui (data de nascimento, endereço, etc.)
 };

 // Adicionar o novo cliente ao array
 clientesFrequentes.push(novoCliente);

 console.log("Novo cliente cadastrado:", novoCliente);
 console.log("Lista de clientes frequentes atualizada:", clientesFrequentes);

 // Exibir mensagem de sucesso
 popularSelectClientes(); // Adiciona a chamada aqui
 exibirAlerta('Cadastro realizado com sucesso!', 'sucesso');

 // Opcional: Limpar o formulário após o cadastro bem-sucedido
 // formularioCadastro.reset(); // reset() limpa todos os campos, mas não remove mensagens de erro
 // Limpar campos específicos
 nomeCompletoInput.value = '';
 emailCadastroInput.value = '';
 telefoneCadastroInput.value = '';
 document.getElementById('rua_cadastro').value = ''; // Limpa campos de endereço também
 document.getElementById('numero_cadastro').value = '';
 document.getElementById('bairro_cadastro').value = '';

 // Impedir a submissão padrão (ainda não temos um backend para processar)
 event.preventDefault();
 }
        });
    }
});

// Atividade 3: Integrar validação de formulário de contato (dentro DOMContentLoaded)
const formularioContato = document.querySelector('form[action="/processar_contato"]');

if (formularioContato) {
    formularioContato.addEventListener('submit', (event) => {
        let formularioValido = true;

        // Obter referências aos elementos de input e erro
        const nomeContatoInput = document.getElementById('nome_contato');
        const emailContatoInput = document.getElementById('email_contato');
        const telefoneContatoInput = document.getElementById('telefone_contato');
        const mensagemContatoInput = document.getElementById('mensagem_contato');

        const erroNomeContatoSpan = document.getElementById('erro-nome-contato');
        const erroEmailContatoSpan = document.getElementById('erro-email-contato');
        const erroTelefoneContatoSpan = document.getElementById('erro-telefone-contato');
        const erroMensagemContatoSpan = document.getElementById('erro-mensagem-contato');

        // Validar Nome (não vazio)
        if (!validarEntradaNaoVazia(nomeContatoInput.value)) {
            erroNomeContatoSpan.textContent = 'Por favor, preencha o campo Nome.';
            formularioValido = false;
        } else {
            erroNomeContatoSpan.textContent = '';
        }

        // Validar Email (não vazio)
        if (!validarEntradaNaoVazia(emailContatoInput.value)) {
            erroEmailContatoSpan.textContent = 'Por favor, preencha o campo Email.';
            formularioValido = false;
        } else {
            erroEmailContatoSpan.textContent = '';
        }

        // Validar Telefone (apenas se preenchido)
        if (validarEntradaNaoVazia(telefoneContatoInput.value) && !validarApenasNumeros(telefoneContatoInput.value)) {
            erroTelefoneContatoSpan.textContent = 'Por favor, insira apenas números no campo Telefone.';
            formularioValido = false;
        } else {
            erroTelefoneContatoSpan.textContent = '';
        }

        // Validar Mensagem (não vazio)
        if (!validarEntradaNaoVazia(mensagemContatoInput.value)) {
            erroMensagemContatoSpan.textContent = 'Por favor, preencha o campo Mensagem.';
            formularioValido = false;
        } else {
            erroMensagemContatoSpan.textContent = '';
        }

        if (!formularioValido) {
            event.preventDefault();
        } else {
            // Se o formulário for válido, você pode adicionar a lógica para enviar os dados
            // Por enquanto, vamos apenas logar no console e impedir a submissão padrão
            console.log('Formulário de contato válido. Dados:', {
                nome: nomeContatoInput.value,
                email: emailContatoInput.value,
                telefone: telefoneContatoInput.value,
                mensagem: mensagemContatoInput.value
            });
            // No futuro, aqui você enviaria os dados para um backend
            event.preventDefault(); // Manter preventDefault por enquanto, já que não temos backend
        }
    });
}

    // Atividade 3: Integrar validação de formulário de feedback (dentro DOMContentLoaded)
 const formularioFeedback = document.querySelector('form[action="/processar_feedback"]');

    if (formularioFeedback) {
        // Obter referências aos campos e elementos span de erro dentro do listener
        const produtoServicoSelect = document.getElementById('produto_servico_feedback');
        const avaliacaoFeedbackRadios = document.querySelectorAll('input[name="avaliacao_feedback"]');
        const comentariosFeedbackTextarea = document.getElementById('comentarios_feedback');

        const erroProdutoServicoSpan = document.getElementById('erro-produto-servico-feedback');
        const erroAvaliacaoSpan = document.getElementById('erro-avaliacao-feedback');
        const erroComentariosSpan = document.getElementById('erro-comentarios-feedback');

 formularioFeedback.addEventListener('submit', (event) => {
 let formularioValido = true;

 // Validar Produto/Serviço (não vazio)
 if (!validarEntradaNaoVazia(produtoServicoSelect.value)) {
 erroProdutoServicoSpan.textContent = 'Por favor, selecione um produto ou serviço.';
 formularioValido = false;
            } else {
 erroProdutoServicoSpan.textContent = '';
            }

 // Validação da avaliação (verificar se pelo menos um rádio está selecionado)
 let avaliacaoSelecionada = false;
            for (const radio of avaliacaoFeedbackRadios) {
 if (radio.checked) {
 avaliacaoSelecionada = true;
 break;
                }
            }
 if (!avaliacaoSelecionada) {
 erroAvaliacaoSpan.textContent = 'Por favor, selecione uma avaliação geral.';
 formularioValido = false;
            } else {
 erroAvaliacaoSpan.textContent = '';
            }

 // Validar Comentários (tornando-o obrigatório)
 if (!validarEntradaNaoVazia(comentariosFeedbackTextarea.value)) {
 erroComentariosSpan.textContent = 'Por favor, preencha o campo de comentários.';
 formularioValido = false;
            } else {
 erroComentariosSpan.textContent = '';
            }


            if (!formularioValido) {
                event.preventDefault();
            }
        });
    }
});

function renderizarClientes() {
	let clientesParaRenderizar = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : clientesFrequentes;
	console.log("Rendering clients:", clientesFrequentes); // Log para depuração
 const listaClientesDiv = document.getElementById('lista-clientes');
 if (listaClientesDiv) {
 listaClientesDiv.innerHTML = ''; // Limpa o conteúdo atual

 if (clientesParaRenderizar.length === 0) {
 listaClientesDiv.textContent = 'Nenhum cliente cadastrado ainda.';
		} else {
 clientesParaRenderizar.forEach(cliente => {
 const clienteElement = document.createElement('div');
				clienteElement.textContent = `ID: ${cliente.id}, Nome: ${cliente.nome}, Telefone: ${cliente.telefone}, Pontos: ${cliente.pontos}`;
				listaClientesDiv.appendChild(clienteElement);
			});
		}
	}
}

function popularSelectClientes() {
	const selectClientes = document.getElementById('selecionar-cliente-pedido');
	if (selectClientes) {
		// Limpa as opções existentes, mantendo apenas a primeira (-- Selecione um cliente --)
		while (selectClientes.options.length > 1) {
			selectClientes.remove(1);
		}

		if (clientesFrequentes.length > 0) {
			clientesFrequentes.forEach(cliente => {
				const option = document.createElement('option');
				option.value = cliente.id;
				option.textContent = cliente.nome;
				selectClientes.appendChild(option);
			});
		}
	}
}

// Atividade 4: Exibir lista de produtos dinamicamente (integrado com DOMContentLoaded)
document.addEventListener('DOMContentLoaded', () => {
	renderizarClientes('lista-clientes'); // Chama renderizarClientes para a lista normal em pedidos.html
	// Verifica se o elemento de lista de clientes do admin existe e renderiza lá também
	const listaClientesAdminDiv = document.getElementById('lista-clientes-admin');
	if (listaClientesAdminDiv) {
		renderizarClientes('lista-clientes-admin');
	}

// Atividade 4: Exibir lista de produtos dinamicamente (integrado com DOMContentLoaded)
document.addEventListener('DOMContentLoaded', () => {
 // ... (código existente do DOMContentLoaded para calculadora e carrossel) ...

    // Função para renderizar a lista de produtos
    function renderizarProdutos(produtosParaExibir) {
        const listaProdutosDiv = document.getElementById('lista-produtos');
        if (listaProdutosDiv) {
            listaProdutosDiv.innerHTML = ''; // Limpa o conteúdo atual

            produtosParaExibir.forEach(produto => {
                const produtoElement = document.createElement('div');
                produtoElement.classList.add('produto-item'); // Adicione uma classe para estilização

                produtoElement.innerHTML = `
                    <h3>${produto.nome}</h3>
                    <p>Preço: ${formatarMoedaBRL(produto.preco)}</p>
                    <button class="adicionar-carrinho" data-id="${produto.id}">Adicionar ao Carrinho</button>
                `;

                listaProdutosDiv.appendChild(produtoElement);

                // Adicionar ícone de favorito
                const favoriteIcon = document.createElement('span');
                favoriteIcon.classList.add('favorite-icon');
                favoriteIcon.textContent = '☆'; // Estrela vazia por padrão
                favoriteIcon.style.cursor = 'pointer'; // Indica que é clicável
                favoriteIcon.style.marginLeft = '10px'; // Espaço entre o botão e o ícone

                // Adicionar ouvinte de evento ao ícone
                favoriteIcon.addEventListener('click', (event) => {
                    event.stopPropagation(); // Impede que o click no ícone acione o ouvinte do produtoElement (se houver)
                    console.log('ID do produto clicado para favorito:', produto.id);
                    // Aqui você chamaria a função para marcar/desmarcar favorito
                    // E atualizaria a aparência do ícone (estrela vazia/preenchida)
                });

                // Verificar se o produto já é favorito e atualizar o ícone inicial
                const produtoAtual = listaCompletaProdutos.find(p => p.id === produto.id);
                if (produtoAtual && produtoAtual.favorito) {
                    favoriteIcon.textContent = '⭐'; // Estrela cheia se for favorito
                }

                favoriteIcon.addEventListener('click', (event) => {
                    event.stopPropagation();
                    const produtoAtual = listaCompletaProdutos.find(p => p.id === produto.id);
                    if (produtoAtual) {
                        produtoAtual.favorito = !produtoAtual.favorito; // Alternar o status favorito
                        event.target.textContent = produtoAtual.favorito ? '⭐' : '☆'; // Atualizar a aparência do ícone
                        console.log(`${produtoAtual.nome} ${produtoAtual.favorito ? 'marcado' : 'desmarcado'} como favorito.`);
                    }
                });
                produtoElement.appendChild(favoriteIcon);

            });

        }
    }

        // Adicionar ouvintes de evento aos botões "Adicionar ao Carrinho"
        listaProdutosDiv.addEventListener('click', (event) => {
 if (event.target.classList.contains('adicionar-carrinho')) {
 const produtoId = event.target.dataset.id;
 adicionarAoCarrinho(produtoId, 1); // Adiciona 1 unidade por padrão
                atualizarCalculadora(); // Atualiza a calculadora ao adicionar um item
 }
        });
 renderizarCarrinho(); // Renderiza o carrinho inicial ao carregar a página
    renderizarProdutos(listaCompletaProdutos); // Renderiza a lista completa de produtos inicialmente


    // Atividade 4: Botão Finalizar Pedido
 const btnFinalizarPedido = document.getElementById('btn-finalizar-pedido');
 if (btnFinalizarPedido) {
 btnFinalizarPedido.addEventListener('click', () => {
 popularSelectClientes(); // Adicionar aqui para preencher o select de clientes

                const formaPagamentoSelecionada = formaPagamentoSelect.value;
                const valorPagoInput = document.getElementById('valorPago');
                const valorPagoFinal = valorPagoInput ? parseFloat(valorPagoInput.value) : 0; // Obter o valor pago

                if (!formaPagamentoSelecionada) {
 exibirAlerta('Por favor, selecione uma forma de pagamento.', 'aviso');
 return; // Impede a criação do pedido
                }

				// Obter o ID do cliente selecionado
				const selecionarClientePedidoSelect = document.getElementById('selecionar-cliente-pedido');
				const clienteSelecionadoId = selecionarClientePedidoSelect ? selecionarClientePedidoSelect.value : '';
				const clienteIdParaPedido = clienteSelecionadoId === '' ? null : parseInt(clienteSelecionadoId); // Converte para número ou null

				// Obter as observações
				const observacoesPedidoTextarea = document.getElementById('observacoes_pedido');
				const observacoes = observacoesPedidoTextarea ? observacoesPedidoTextarea.value : '';

				// Obter os detalhes do endereço de entrega e criar o objeto
				const enderecoEntrega = {
					rua: document.getElementById('rua-entrega')?.value || '',
					numero: document.getElementById('numero-entrega')?.value || '',
					bairro: document.getElementById('bairro-entrega')?.value || '',
					cep: document.getElementById('cep-entrega')?.value || '',
				};

                const novoPedido = criarObjetoPedido(valorPagoFinal, formaPagamentoSelecionada, clienteIdParaPedido, observacoes, enderecoEntrega);
 renderizarRankingVendas(); // Adicionar aqui para exibir o ranking inicial

 renderizarProdutosFavoritos();
    renderizarHistoricoPedidos(); // Renderiza o histórico inicial ao carregar a página
});

// Atividade 3: Integrar sistema de busca
document.addEventListener('DOMContentLoaded', () => {
    const inputBuscaProdutos = document.getElementById('input-busca-produtos');

    if (inputBuscaProdutos) {
 inputBuscaProdutos.addEventListener('input', (event) => {
 const termoBusca = event.target.value;
 const resultadosBusca = buscarProdutos(listaCompletaProdutos, termoBusca);
 renderizarProdutos(resultadosBusca);
        });
    }

// Opcional: Chamar a função atualizarCalculadora uma vez ao carregar a página para mostrar os valores iniciais (fora do DOMContentLoaded, se necessário para outros elementos)
// Dependendo de quais elementos de calculadora precisam ser atualizados, você pode chamar aqui ou dentro do DOMContentLoaded
// Se os elementos da calculadora estão dentro de um formulário que só aparece após DOMContentLoaded, é melhor chamá-la dentro.
    // Se eles estão sempre presentes, uma chamada aqui pode ser útil.1
// atualizarCalculadora();

// Atividade 3: Manipulação de Strings e Dados

function formatarNomeProprio(nome) {
    if (typeof nome !== 'string' || nome.length === 0) {
        return ""; // Retorna vazio para entradas inválidas
    }
    return nome.charAt(0).toUpperCase() + nome.slice(1).toLowerCase();
}

// Exemplo de uso:
let nomeCliente = "joão silva";
let nomeFormatado = formatarNomeProprio(nomeCliente);
console.log("Nome formatado:", nomeFormatado); // Saída: João silva
function formatarMoedaBRL(valor) {
    if (typeof valor !== 'number' || isNaN(valor)) {
        return "R$ 0,00"; // Retorna um valor padrão para entradas inválidas
    }
    return "R$ " + valor.toFixed(2).replace('.', ','); // Substitui o ponto pela vírgula para o formato brasileiro
}

// Exemplo de uso:
let precoProduto = 15.75;
let precoFormatado = formatarMoedaBRL(precoProduto);
console.log("Preço formatado:", precoFormatado); // Saída: R$ 15,75
// Vamos precisar de um contador para os produtos
let contadorProdutos = 0;

function gerarCodigoProduto(categoria) {
    if (typeof categoria !== 'string' || categoria.length < 3) {
        categoria = "GEN"; // Categoria genérica se a entrada for inválida
    }
    const siglaCategoria = categoria.substring(0, 3).toUpperCase();
    contadorProdutos++;
    const numeroProduto = contadorProdutos.toString().padStart(3, '0'); // Garante 3 dígitos com zero à esquerda
    return siglaCategoria + numeroProduto;
}

// Exemplo de uso:
let codigoPao = gerarCodigoProduto("Pães");
let codigoBolo = gerarCodigoProduto("Bolos");
console.log("Código do Pão:", codigoPao); // Saída: PAE001 (ou similar, dependendo do contador)
console.log("Código do Bolo:", codigoBolo); // Saída: BOL002 (ou similar)
function saudacaoPersonalizada(nome) {
    const horaAtual = new Date().getHours();
    let periodoDia;

    if (horaAtual >= 5 && horaAtual < 12) {
        periodoDia = "Bom dia";
    } else if (horaAtual >= 12 && horaAtual < 18) {
        periodoDia = "Boa tarde";
    } else {
        periodoDia = "Boa noite";
    }

    return `${periodoDia}, ${formatarNomeProprio(nome)}! Bem-vindo(a) à Padaria Doce Sabor.`;
}

// Exemplo de uso:
let mensagemSaudacao = saudacaoPersonalizada("maria");
console.log(mensagemSaudacao); // Saída: Bom dia/tarde/noite, Maria! Bem-vindo(a) à Padaria Doce Sabor.
function validarEntradaNaoVazia(entrada) {
    return entrada !== null && entrada !== undefined && entrada.trim() !== "";
}

function validarApenasNumeros(entrada) {
    return /^\d+$/.test(entrada); // Verifica se a string contém apenas dígitos
}

// Exemplo de uso:
let nomeUsuario = prompt("Digite seu nome:");
if (validarEntradaNaoVazia(nomeUsuario)) {
    console.log("Nome válido:", nomeUsuario);
} else {
    console.log("Por favor, digite seu nome.");
}

let idadeUsuario = prompt("Digite sua idade:");
if (validarApenasNumeros(idadeUsuario)) {
    console.log("Idade válida:", idadeUsuario);
} else {
    console.log("Por favor, digite apenas números para a idade.");
}
function buscarProdutos(listaProdutos, termoBusca) {
    if (!validarEntradaNaoVazia(termoBusca)) {
        return []; // Retorna array vazio se o termo de busca for vazio
    }
    const termoBuscaLowerCase = termoBusca.toLowerCase();
    return listaProdutos.filter(produto =>
        produto.nome.toLowerCase().includes(termoBuscaLowerCase) ||
        produto.categoria.toLowerCase().includes(termoBuscaLowerCase)
        // Você pode adicionar mais campos para buscar aqui
    );
}

// Exemplo de uso (usando o array de objetos de produto da Atividade 1):
const produtosParaBusca = [
    { nome: "Pão Francês", preco: 0.50, estoque: 100, categoria: "Pães" },
    { nome: "Bolo de Chocolate", preco: 25.00, estoque: 10, categoria: "Bolos" },
    { nome: "Croissant", preco: 4.00, estoque: 30, categoria: "Pães" }
];

let resultadosBusca = buscarProdutos(produtosParaBusca, "bolo");
console.log("Resultados da busca por 'bolo':", resultadosBusca);
function formatarDataHora(data) {
    const dia = String(data.getDate()).padStart(2, '0');
    const mes = String(data.getMonth() + 1).padStart(2, '0'); // Meses são de 0 a 11
    const ano = data.getFullYear();
    const horas = String(data.getHours()).padStart(2, '0');
    const minutos = String(data.getMinutes()).padStart(2, '0');
    const segundos = String(data.getSeconds()).padStart(2, '0');

    return `${dia}/${mes}/${ano} ${horas}:${minutos}:${segundos}`;
}

// Exemplo de uso:
let dataPedido = new Date(); // Data e hora atuais
let dataHoraFormatada = formatarDataHora(dataPedido);
console.log("Data e Hora do Pedido:", dataHoraFormatada);

// Atividade 4: Arrays e Listas Dinâmicas

function renderizarCarrinho() {
    const listaCarrinhoDiv = document.getElementById('lista-carrinho');
    if (listaCarrinhoDiv) {
        // Limpa o conteúdo atual do carrinho
        listaCarrinhoDiv.innerHTML = '';

        if (carrinho.length === 0) {
            listaCarrinhoDiv.textContent = 'Seu carrinho está vazio.';
        } else {
            carrinho.forEach(item => {
                const itemCarrinhoDiv = document.createElement('div');
                const itemSubtotal = item.produto.preco * item.quantidade;
                itemCarrinhoDiv.textContent = `${item.produto.nome} - Quantidade: ${item.quantidade} - Subtotal: R$ ${itemSubtotal.toFixed(2)}`;

                const removerBotao = document.createElement('button');
                removerBotao.textContent = 'Remover';
                removerBotao.addEventListener('click', () => {
                    removerDoCarrinho(item.produto.id);
                    atualizarCalculadora(); // Atualiza a calculadora ao remover um item
                });
                itemCarrinhoDiv.appendChild(removerBotao);

                listaCarrinhoDiv.appendChild(itemCarrinhoDiv);
            });
        }
    }
}

document.addEventListener('DOMContentLoaded', () => {
	const inputBuscaClientes = document.getElementById('input-busca-clientes');
	const listaClientesDiv = document.getElementById('lista-clientes');
	if (inputBuscaClientes) {
		inputBuscaClientes.addEventListener('input', (event) => {
			const termoBusca = event.target.value;
			const termoBuscaLowerCase = termoBusca.toLowerCase();
			const clientesFiltrados = clientesFrequentes.filter(cliente =>
				cliente.nome.toLowerCase().includes(termoBuscaLowerCase) ||
				cliente.telefone.toLowerCase().includes(termoBuscaLowerCase)
			);
			renderizarClientes(clientesFiltrados); // Renderiza a lista filtrada
		});
	}
});

function renderizarHistoricoPedidos(containerId) {
    const historicoPedidosDiv = document.getElementById(containerId);
	
	if (historicoPedidosDiv) {
        // Limpa o conteúdo atual do histórico
        historicoPedidosDiv.innerHTML = '';

        if (historicoPedidosHoje.length === 0) {
            historicoPedidosDiv.textContent = 'Nenhum pedido registrado ainda.';
        } else {
            historicoPedidosHoje.forEach((pedido, index) => { // Adiciona index para mostrar o número do pedido
                const pedidoElement = document.createElement('div');
                pedidoElement.classList.add('historico-pedido-item'); // Adiciona classe para estilização
                // Exibe informações gerais do pedido
                pedidoElement.innerHTML = `
                    <h3>Pedido #${index + 1} (ID: ${pedido.id})</h3>
                    <p>Data/Hora: ${formatarDataHora(pedido.dataHora)}</p>
                    <p>Cliente ID: ${pedido.clienteId || 'N/A'}</p> <!-- Exibe o ID do cliente -->
                    <p>Forma de Pagamento: ${pedido.formaPagamento || 'N/A'}</p> <!-- Exibe a forma de pagamento -->
                    <p>Observações: ${pedido.observacoes || 'N/A'}</p> <!-- Exibe as observações -->
                    <p>Endereço de Entrega: ${pedido.enderecoEntrega ? `${pedido.enderecoEntrega.rua}, ${pedido.enderecoEntrega.numero}, ${pedido.enderecoEntrega.bairro}, ${pedido.enderecoEntrega.cep}` : 'N/A'}</p> <!-- Exibe o endereço de entrega -->
                    <p>Total Geral: ${formatarMoedaBRL(pedido.totalGeral)}</p>
                    <p>Valor Pago: ${formatarMoedaBRL(pedido.valorPago)}</p>
                    <p>Troco: ${formatarMoedaBRL(pedido.troco)}</p>
                    <p>Pontos Ganhos: ${pedido.pontosGanhos}</p>
                `;
                // Adicionar a lista de itens
                const itensList = document.createElement('ul');
                itensList.classList.add('lista-itens-pedido'); // Classe para estilização da lista de itens

                pedido.itens.forEach(item => {
                    const itemElement = document.createElement('li');
                    // Exibe o nome do produto e a quantidade
                    itemElement.textContent = `${item.produto.nome} x ${item.quantidade}`;
                    itensList.appendChild(itemElement);
                });

                pedidoElement.appendChild(itensList);
                historicoPedidosDiv.appendChild(pedidoElement);
            });

                }
            });
        }
    }
}

function renderizarRankingVendas(containerId) {
	const rankingContainer = document.getElementById(containerId);
	if (rankingContainer) {
		rankingContainer.innerHTML = ''; // Limpa o conteúdo atual
		const ranking = obterRankingVendas();

		if (ranking.length === 0 || ranking.every(produto => produto.vendidos === 0)) {
 rankingContainer.textContent = 'Nenhum produto vendido ainda para o ranking.';
		} else {
			ranking.forEach((produto, index) => {
				if (produto.vendidos > 0) {
					const rankingElement = document.createElement('div');
					rankingElement.textContent = `#${index + 1}: ${produto.nome} - Vendidos: ${produto.vendidos}`;
					rankingContainer.appendChild(rankingElement);
				}
			});
		}
	}
}

let listaCompletaProdutos = [
    { id: "PAO001", nome: "Pão Francês", preco: 0.50, estoque: 100, categoria: "Pães", favorito: false },
    { id: "BOL001", nome: "Bolo de Chocolate", preco: 25.00, estoque: 10, categoria: "Bolos", favorito: false },
    { id: "BEB001", nome: "Café Expresso", preco: 4.50, estoque: 50, categoria: "Bebidas", favorito: false },
    { id: "DOC001", nome: "Sonho de Creme", preco: 5.00, estoque: 25, categoria: "Doces", favorito: false }
    // Adicione mais produtos aqui
];
let carrinho = [];

function adicionarAoCarrinho(produtoId, quantidade) {
    const produto = listaCompletaProdutos.find(p => p.id === produtoId);

    if (!produto) {
        console.log("Produto não encontrado!");
        return;
    }

    if (quantidade <= 0 || quantidade > produto.estoque) {
        console.log("Quantidade inválida ou superior ao estoque!");
        return;
    }

    const itemNoCarrinho = carrinho.find(item => item.produto.id === produtoId);

    if (itemNoCarrinho) {
        itemNoCarrinho.quantidade += quantidade;
    } else {
        carrinho.push({ produto: produto, quantidade: quantidade });
    }

    produto.estoque -= quantidade; // Diminuir do estoque ao adicionar ao carrinho
    console.log("Carrinho atualizado:", carrinho);
    console.log("Estoque atualizado:", produto.nome, produto.estoque);
    renderizarCarrinho();
}

function removerDoCarrinho(produtoId) {
    const index = carrinho.findIndex(item => item.produto.id === produtoId);

    if (index > -1) {
        const quantidadeRemovida = carrinho[index].quantidade;
        carrinho[index].produto.estoque += quantidadeRemovida; // Devolver ao estoque
        carrinho.splice(index, 1);
        console.log("Carrinho atualizado após remoção:", carrinho);
        console.log("Estoque atualizado após remoção:", listaCompletaProdutos.find(p => p.id === produtoId).nome, listaCompletaProdutos.find(p => p.id === produtoId).estoque);
        renderizarCarrinho();
    } else {
        console.log("Produto não encontrado no carrinho!");
    }
}

// Exemplo de uso:
adicionarAoCarrinho("PAO001", 5);
adicionarAoCarrinho("BOL001", 1);
adicionarAoCarrinho("PAO001", 3); // Adicionando mais do mesmo item
// removerDoCarrinho("BOL001");
let ClientesFrequentes = [
// Movido a inicialização de historicoPedidosHoje para fora da função para evitar reset a cada chamada
function registrarPedido(pedido) {
    historicoPedidosHoje.push(pedido);
    console.log("Histórico de pedidos do dia:", historicoPedidosHoje);
}

// Exemplo (ainda precisaremos criar a estrutura do objeto pedido):
// registrarPedido({ id: "PED001", itens: carrinho, total: 50.00, data: new Date() });
function marcarComoFavorito(produtoId) {
    const produto = listaCompletaProdutos.find(p => p.id === produtoId);
    if (produto) {
        produto.favorito = true;
        console.log(`${produto.nome} marcado como favorito.`);
    } else {
        console.log("Produto não encontrado!");
    }
}

function DesmarcarFavorito(produtoId) {
    const produto = listaCompletaProdutos.find(p => p.id === produtoId);
    if (produto) {
        produto.favorito = false;
        console.log(`${produto.nome} desmarcado como favorito.`);
    } else {
        console.log("Produto não encontrado!");
    }
}

Function ObterFavoritos() {
    return ListaCompletaProdutos.filter(produto => produto.favorito);
}

// Exemplo de uso:
MarcarComoFavorito("PAO001");
MarcarComoFavorito("DOC001");
console.log("Produtos favoritos:", obterFavoritos());
// desmarcarFavorito("PAO001");
// Adicione a propriedade 'vendidos: 0' aos objetos em listaCompletaProdutos
// Ex: { id: "PAO001", nome: "Pão Francês", preco: 0.50, estoque: 100, categoria: "Pães", favorito: false, vendidos: 0 }

function atualizarRankingVendas(pedido) {
    pedido.itens.forEach(item => {
        const produto = listaCompletaProdutos.find(p => p.id === item.produto.id);
        if (produto) {
            produto.vendidos += item.quantidade;
        }
    });
}

function obterRankingVendas() {
    return listaCompletaProdutos.slice().sort((a, b) => b.vendidos - a.vendidos); // Cria uma cópia e ordena
}

// Exemplo (chame isso ao registrar um pedido):
// atualizarRankingVendas(ultimoPedidoRegistrado);
// console.log("Ranking de Vendas:", obterRankingVendas());
function exibirAlerta(mensagem) {
    console.log("ALERTA:", mensagem);
    const alertaContainer = document.getElementById('alerta-container');
    const alertaMensagemElement = document.createElement('div');
// exibirAlerta("Estoque baixo para Pão Francês!");
// Atividade 5: Objetos e Estruturas Complexas

function exibirAlerta(mensagem, tipo = 'aviso') { // Agora aceita o tipo de alerta
    const listaFavoritosDiv = document.getElementById('lista-favoritos');
    if (listaFavoritosDiv) {
        // Removido o loop desnecessário e a lógica de alerta duplicada aqui
        // Esta parte da função renderizarProdutosFavoritos estava duplicada e foi removida

        // Código de renderização de favoritos movido para a função renderizarProdutosFavoritos
        const produtosFavoritos = obterFavoritos(); // Obter favoritos novamente para renderizar
        if (produtosFavoritos.length === 0) {
            listaFavoritosDiv.textContent = 'Nenhum produto favorito ainda.';
        } else {
            produtosFavoritos.forEach(produto => {
                const produtoFavoritoElement = document.createElement('div');
 // Este setTimeout estava removendo o elemento errado
                }, 5000); // Remove após 5 segundos
                listaFavoritosDiv.appendChild(produtoFavoritoElement); // Adiciona o elemento do favorito
                }, 3000); // 3000 milissegundos = 3 segundos
                
            });
        }
    }
}
function renderizarProdutosFavoritos() {
    const listaFavoritosDiv = document.getElementById('lista-favoritos');
    if (listaFavoritosDiv) {
        listaFavoritosDiv.innerHTML = ''; // Limpa o conteúdo atual

        const produtosFavoritos = obterFavoritos();
        if (produtosFavoritos.length === 0) {
            listaFavoritosDiv.textContent = 'Nenhum produto favorito ainda.';
        } else {
            produtosFavoritos.forEach(produto => {
                const produtoFavoritoElement = document.createElement('div');
                produtoFavoritoElement.textContent = `${produto.nome} - ${formatarMoedaBRL(produto.preco)}`;
                listaFavoritosDiv.appendChild(produtoFavoritoElement);
            });
        }
    }
}
// Exemplo de estrutura de objeto produto (já usada na Atividade 4)
/*
const produtoExemplo = {
    id: "ID_UNICO", // Identificador único
    nome: "Nome do Produto",
    preco: 0.00,
    estoque: 0,
    categoria: "Categoria do Produto",
    favorito: false,
    vendidos: 0,
    // Adicione outras propriedades como descrição, imagem, etc.
};
*/

// A lista completa de produtos (já criada na Atividade 4) é um array de objetos produto.
let ListaCompletaProdutos = [
    { id: "PAO001", nome: "Pão Francês", preco: 0.50, estoque: 100, categoria: "Pães", favorito: false, vendidos: 0 },
    { id: "BOL001", nome: "Bolo de Chocolate", preco: 25.00, estoque: 10, categoria: "Bolos", favorito: false, vendidos: 0 },
    { id: "BEB001", nome: "Café Expresso", preco: 4.50, estoque: 50, categoria: "Bebidas", favorito: false, vendidos: 0 },
    { id: "DOC001", nome: "Sonho de Creme", preco: 5.00, estoque: 25, categoria: "Doces", favorito: false, vendidos: 0 }
    // Adicione mais produtos aqui
];


// Exemplo de estrutura de objeto cliente (já usada na Atividade 4)
/*
const clienteExemplo = {
    id: 0, // Identificador único do cliente
    nome: "Nome do Cliente",
    telefone: "Telefone do Cliente",
    pontos: 0,
    // Adicione outras propriedades como email, endereço, histórico de compras, etc.
};
*/

// A lista de clientes frequentes (já criada na Atividade 4) é um array de objetos cliente.
let clientesFrequentes = [
    { id: 1, nome: "Ana Souza", telefone: "(11) 9876-5432", pontos: 150 },
    { id: 2, nome: "Bruno Costa", telefone: "(21) 9987-6543", pontos: 50 },
    // Adicione mais clientes aqui
];

// Estrutura do objeto pedido
/*
const pedidoExemplo = {
    id: "ID_PEDIDO_UNICO", // Ex: PED001, gerado automaticamente
    itens: [ // Array de objetos representando os itens no pedido
        {
            produto: { // Objeto produto simplificado ou referência ao produto completo
                id: "ID_PRODUTO",
                nome: "Nome do Produto",
                preco: 0.00
                // Não precisa de estoque ou favorito aqui, pois é um registro do que foi comprado
            },
            quantidade: 0
        }
        // Mais itens...
    ],
    subtotal: 0.00,
    desconto: 0.00,
    imposto: 0.00,
    taxaEntrega: 0.00,
    totalGeral: 0.00,
    valorPago: 0.00,
    troco: 0.00,
    pontosGanhos: 0,
    dataHora: new Date(), // Objeto Date para registrar a data e hora
    status: "pendente" // Ex: "pendente", "concluido", "cancelado"
    // Adicione outras propriedades como cliente (referência ou objeto cliente), forma de pagamento, etc.
};
*/



// Função para criar um novo objeto pedido a partir do carrinho (exemplo)
function criarObjetoPedido(valorPagoFinal, formaPagamentoSelecionada, clienteIdAssociado, observacoesPedido, enderecoEntregaPedido) {
    // Esta função calcula os totais com base no carrinho atual
    // e agora aceita o ID do cliente associado
    // Por enquanto, vamos criar uma estrutura básica.
    let novoPedido = {
        id: "PED" + (historicoPedidosHoje.length + 1).toString().padStart(3, '0'), // ID simples
        itens: [], // Copiar itens do carrinho
        subtotal: 0.00,
        desconto: 0.00,
        imposto: 0.00,
        taxaEntrega: 0.00,
        totalGeral: 0.00,
        valorPago: 0.00,
        troco: 0.00, // Será calculado no final
        pontosGanhos: 0,
        dataHora: new Date(), // Objeto Date para registrar a data e hora
		clienteId: clienteIdAssociado, // Adiciona a referência ao cliente
        formaPagamento: formaPagamentoSelecionada, // Adiciona a forma de pagamento
        observacoes: observacoesPedido, // Adiciona as observações
        enderecoEntrega: enderecoEntregaPedido, // Adiciona o endereço de entrega
 erroTermosSpan.textContent = ''; // Limpa a mensagem de erro se válido
        status: "pendente"
    };

 // Copiar itens do carrinho para o pedido e calcular subtotal
    carrinho.forEach(item => {
        novoPedido.itens.push({
            produto: { // Cópia das propriedades relevantes do produto
                id: item.produto.id,
                nome: item.produto.nome,
                preco: item.produto.preco,
            },
            quantidade: item.quantidade,
        });
        novoPedido.subtotal += item.produto.preco * item.quantidade;
    });

 // Calcular desconto por volume
    let totalItens = novoPedido.itens.reduce((sum, item) => sum + item.quantidade, 0);
    let descontoPercentual = 0;
    configuracoesSistema.regrasDescontoVolume.sort((a, b) => b.quantidadeMinima - a.quantidadeMinima).forEach(regra => {
 if (totalItens >= regra.quantidadeMinima && descontoPercentual === 0) {
            descontoPercentual = regra.percentual;
        }
    });
    novoPedido.desconto = novoPedido.subtotal * descontoPercentual;
    novoPedido.subtotalComDesconto = novoPedido.subtotal - novoPedido.desconto;

 // Calcular impostos, taxa de entrega e total geral

    novoPedido.imposto = novoPedido.subtotalComDesconto * configuracoesSistema.impostoPercentual;
    novoPedido.taxaEntrega = configuracoesSistema.taxaEntrega;
    novoPedido.totalGeral = novoPedido.subtotalComDesconto + novoPedido.imposto + novoPedido.taxaEntrega;

    // Calcular pontos ganhos (se aplicável)
    novoPedido.pontosGanhos = Math.floor(novoPedido.totalGeral); // 1 ponto por Real

 // Usar o valor pago final passado como argumento
    novoPedido.valorPago = parseFloat(valorPagoFinal) || 0; // Garante que é um número
    novoPedido.troco = novoPedido.valorPago - novoPedido.totalGeral;

    return novoPedido;


document.addEventListener('DOMContentLoaded', () => {
    const carouselSlides = document.querySelector('.carousel-slides');
    const slides = document.querySelectorAll('.carousel-slide');
    const btnPrev = document.querySelector('.carousel-prev'); // Supondo que estes botões existem no HTML
    const btnNext = document.querySelector('.carousel-next'); // Supondo que estes botões existem no HTML
    const dotsContainer = document.querySelector('.carousel-dots'); // Supondo que este contêiner existe no HTML

    let currentIndex = 0;
    const totalSlides = slides.length;
    // Certifique-se de que temos pelo menos um slide para obter a largura
    const slideWidth = slides.length > 0 ? slides[0].offsetWidth : 0;

    // Função para rolar para um slide específico
    function showSlide(index) {
        if (carouselSlides && slideWidth > 0) {
            // Calcular a posição de rolagem
            const scrollAmount = index * slideWidth;

            // Rolar o contêiner para a posição calculada
            carouselSlides.scrollLeft = scrollAmount;
        } else {
             console.error("Elementos do carrossel ou largura do slide não encontrados.");
        }

        // Atualiza os indicadores de página (dots)
        if (dotsContainer) { // Supondo que updateDots está definida em outro lugar
            updateDots(index);
        }
    }

    // Função para mostrar o slide anterior
    function prevSlide() {
        currentIndex = (currentIndex - 1 + totalSlides) % totalSlides;
        showSlide(currentIndex);
    }

    // Cria os indicadores de página (dots)
    function createDots() {
        if (dotsContainer) {
            for (let i = 0; i < totalSlides; i++) {
                const dot = document.createElement('span');
                dot.classList.add('carousel-dot');
                dot.addEventListener('click', () => {
                    showSlide(i);
                    currentIndex = i; // Atualiza o índice atual ao clicar no dot\n
                });
                dotsContainer.appendChild(dot);
            }
        }
    }

     // Atualiza a classe 'active' nos indicadores de página (dots)
    function updateDots(activeIndex) {
        const dots = document.querySelectorAll('.carousel-dot');
        dots.forEach((dot, index) => {
            if (index === activeIndex) {
                dot.classList.add('active');
            } else {
                dot.classList.remove('active');
            }
        });
    }


    // Adiciona ouvintes de evento aos botões de navegação (se existirem)
    if (btnPrev) {
        btnPrev.addEventListener('click', () => {
            currentIndex = (currentIndex - 1 + totalSlides) % totalSlides;
            showSlide(currentIndex);
        });
    }
    if (btnNext) {
        btnNext.addEventListener('click', () => {
            currentIndex = (currentIndex + 1) % totalSlides;
            showSlide(currentIndex);
        });
    }

    // Cria os indicadores de página ao carregar (se o contêiner existir)
    createDots();

    // Mostra o primeiro slide ao carregar a página
    showSlide(currentIndex);

    // Opcional: Auto-play do carrossel (remove ou comente se não quiser auto-play)
    // setInterval(nextSlide, 5000); // Troca de slide a cada 5 segundos

});
